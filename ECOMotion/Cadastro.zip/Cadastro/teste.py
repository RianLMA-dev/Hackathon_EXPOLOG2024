
class Usuario:
    def __init__(self, nome, email, senha):
        self.nome = nome
        self.email = email
        self.senha = senha

class Caminhoneiro(Usuario):
    def __init__(self, nome, email, senha, telefone, cpf, cnh):
        super().__init__(nome, email, senha)
        self.telefone = telefone
        self.cpf = cpf
        self.cnh = cnh

class Empresa(Usuario):
    def __init__(self, nome, email, senha, cnpj):
        super().__init__(nome, email, senha)

class Cadastro(Usuario):
    def cadastrar_usuario():
        tipo_usuario = input("Você é um caminhoneiro ou uma empresa? (c/e): ").lower()
        
        if tipo_usuario == 'c':
            nome = input("Digite seu nome: ")
            email = input("Digite seu email: ")
            senha = input("Digite sua senha: ")
            telefone = input("Digite seu telefone: ")
            cpf = input("Digite seu CPF: ")
            cnh = input("Digite sua CNH: ")
            from validacaoDados import TestCaminhoneiro
            if(TestCamioneiro.is_valid_cpf(cpf) and TestCamioneiro.is_valid_email(email) and TestCamioneiro.is_valid_password(senha)):
                usuario = Caminhoneiro(nome, email, senha, telefone, cpf, cnh)
        elif tipo_usuario == 'e':
            nome = input("Digite seu nome: ")
            email = input("Digite seu email: ")
            senha = input("Digite sua senha: ")
            cnpj = input("Digite seu CNPJ: ")
            from validacaoDados import TestEmpresa
            if(TestEmpresa.is_valid_email(email) and TestEmpresa.is_valid_password(senha)):
                usuario = Empresa(nome, email, senha, cnpj)
        else:
            print("Tipo de usuário inválido.")
            return None
        
        return usuario

