import re
import unittest
from teste import Usuario, Caminhoneiro, Empresa

#Testa os dados de Caminhoneiro
class TestCaminhoneiro(unittest.TestCase):
    def test_email_validation(self):
        def is_valid_email(email):
            regex = r'^\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
            return re.match(regex, email) is not None

        valid_email = "valid.email@example.com"
        invalid_email = "invalid-email.com"

        self.assertTrue(is_valid_email(valid_email))
        self.assertFalse(is_valid_email(invalid_email))

    def test_password_validation(self):
            def is_valid_password(password):
                if len(password) < 8 and len(password) > 15:
                    return False
                if not re.search(r'[A-Z]', password):
                    return False
                if not re.search(r'[a-z]', password):
                    return False
                if not re.search(r'[0-9]', password):
                    return False
                if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
                    return False
                return True

            valid_password = "Valid1Password!"
            invalid_password = "short1!"

            self.assertTrue(is_valid_password(valid_password))
            self.assertFalse(is_valid_password(invalid_password))

    def test_cpf_validation(self):
        def is_valid_cpf(cpf):
            cpf = ''.join(filter(str.isdigit, cpf))
            if len(cpf) != 11 or cpf == cpf[0] * 11:
                return False
            for i in range(9, 11):
                value = sum((int(cpf[num]) * ((i + 1) - num) for num in range(0, i)))
                digit = ((value * 10) % 11) % 10
                if digit != int(cpf[i]):
                    return False
            return True

        valid_cpf = "123.456.789-09"
        invalid_cpf = "123.456.789-00"

        self.assertTrue(is_valid_cpf(valid_cpf))
        self.assertFalse(is_valid_cpf(invalid_cpf))

if __name__ == '__main__':
    unittest.main()

#Testa os dados de Empresa    
class TestEmpresa(unittest.TestCase):
    def test_email_validation(self):
        def is_valid_email(email):
            regex = r'^\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
            return re.match(regex, email) is not None

        valid_email = "valid.email@example.com"
        invalid_email = "invalid-email.com"

        self.assertTrue(is_valid_email(valid_email))
        self.assertFalse(is_valid_email(invalid_email))

    def test_password_validation(self):
            def is_valid_password(password):
                if len(password) < 8 and len(password) > 15:
                    return False
                if not re.search(r'[A-Z]', password):
                    return False
                if not re.search(r'[a-z]', password):
                    return False
                if not re.search(r'[0-9]', password):
                    return False
                if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
                    return False
                return True

            valid_password = "Valid1Password!"
            invalid_password = "short1!"

            self.assertTrue(is_valid_password(valid_password))
            self.assertFalse(is_valid_password(invalid_password))

    def validar_cnpj(cnpj):
        
        cnpj = ''.join(filter(str.isdigit, cnpj))
        if(len(cnpj) != 14):
            return False

        if cnpj == cnpj[0] * len(cnpj):
            return False
        
        def calcular_digito(cnpj, pesos):
            soma = sum(int(cnpj[i]) * pesos[i] for i in range(len(pesos)))
            resto = soma % 11
            return 0 if resto < 2 else 11 - resto

        pesos_1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        pesos_2 = [6] + pesos_1

        digito_1 = calcular_digito(cnpj[:12], pesos_1)
        if int(cnpj[12]) != digito_1:
            return False

        digito_2 = calcular_digito(cnpj[:13], pesos_2)
        if int(cnpj[13]) != digito_2:
            return False

        return True

if __name__ == '__main__':
    unittest.main()
        
   